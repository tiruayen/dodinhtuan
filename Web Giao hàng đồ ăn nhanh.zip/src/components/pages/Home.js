// src/components/pages/Home.js
import React from 'react';
import './Home.css';
import Vuivai from './home/vuivai';
const Home = () => {
   return (
      <div>
          <Vuivai />
      </div>
  );
};

export default Home;